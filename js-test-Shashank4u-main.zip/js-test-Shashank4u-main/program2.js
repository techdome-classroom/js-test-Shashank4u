/**
 * @param {string} s
 * @return {number}
 */
var romanToInt = function(s) {
    
};


module.exports={romanToInt}